import React, { useState,useRef } from 'react' 

import { Button } from 'reactstrap' 
import {CSVReader} from "papaparse"
import * as XLSX from "xlsx" 
import { Label, Table, Row, Col } from "reactstrap"; 
import { ColumnDirective, ColumnsDirective, GridComponent, Inject, Sort, Toolbar, Filter, ExcelExport, RowSelectEventArgs, DialogEditEventArgs, FilterSettingsModel, Edit, RowDropSettingsModel, RowDD, SelectionSettingsModel, Selection, PdfExport } from '@syncfusion/ej2-react-grids';
import {
    createTheme,
    FormControl,
    MenuItem,
    MuiThemeProvider,
    Select,
    TextareaAutosize,
    TextField,
  } from "@material-ui/core"; 
const JsonTable = require("ts-react-json-table");
const Chetan = () => {   
      

    
    const [items,setItems]=useState([]) 
    const [Format,setFormat]=useState()   
    const  toolbarOptions = ['ExcelExport'];
    let excelData
    const data = [
        {
          SetName: "Report 1",
          FieldCodes:
            "{OrderDate},{OrderNumber},{OrderName},{ModulePosn},{ModuleName}_{ModuleSize},{PanelCode},{PanelName},{FinishedLength},{FinishedWidth},{FinishedThickness},{CutLength},{CutWidth},{CutThickness},{FinishedMatlNameFull},{CoreMaterial},{TopLaminate},{BottomLaminate},{FinishedGrainDir},{TLGrainDir},{BLGrainDir},{W1EBThickness} X {W1EBWidth}_{W1EBColour}_EB,{W2EBThickness} X {W2EBWidth}_{W2EBColour}_EB,{L1EBThickness} X {L1EBWidth}_{L1EBColour}_EB,{L2EBThickness} X {L2EBWidth}_{L2EBColour}_EB,{TopBarCode},{BottomBarCode},{ModuleComment}",
          FieldNames:
            "OrderDate,OrderNumber,OrderName,ModuleNumber,Description,Panel barcode,Description,FinishedLength,FinishedWidth,FinishedThickness,CutLength,CutWidth,CutThickness,FinalBoardMaterial,Material,SurfaceTop,SurfaceBottom,GrainDirection,TLGrainDir,BLGrainDir,EdgeBottom W1,EdgeRight L1,EdgeTop W2,EdgeLeft L2,TopBarCode,BottomBarCode,Instructions",
        },
        {
          SetName: "Report 2",
          FieldCodes:
            "{OrderNumber},{OrderName},{OrderDate},{ModulePosn},{PanelName},{PanelCode},{ModuleName}_{ModuleSize},{FinishedMatlNameFull},{CoreMaterial},{W1EBThickness} X {W1EBWidth}_{W1EBColour}_EB,{W2EBThickness} X {W2EBWidth}_{W2EBColour}_EB,{L1EBThickness} X {L1EBWidth}_{L1EBColour}_EB,{L2EBThickness} X {L2EBWidth}_{L2EBColour}_EB,{TopLaminate},{TopBarCode},{BottomLaminate},{BottomBarCode},{CutLength},{CutWidth},{CutThickness},{FinishedLength},{FinishedWidth},{FinishedThickness},{Quantity},{FinishedGrainDir},{TLGrainDir},{BLGrainDir},{ModuleComment},{ModuleRemarks}",
          FieldNames:
            "OrderNumber,OrderName,OrderDate,POSNo,Description,Panel barcode,Article name,Final boardoutput,Material,EdgeBottom W1,EdgeRight W2,EdgeTop L1,EdgeLeft L2,Surface top,Top barcode,Surface bottom,Bottom barcode,CutLength,CutWidth,CutThickness,FinishedLength,FinishedWidth,FinishedThickness,Qty,GrainFlag,TL Grain direction,BL Grain direction,Module Comment,Cabinet Remarks",
        },
        {
          SetName: "Report 3",
          FieldCodes:
            "{OrderNumber},{OrderName},{OrderDate},{ModulePosn},{PanelName},{PanelCode},{ModuleName}_{ModuleSize},{FinishedMatlNameFull},{CoreMaterial},{W1EBThickness} X {W1EBWidth}_{W1EBColour}_EB,{L1EBThickness} X {L1EBWidth}_{L1EBColour}_EB,{W2EBThickness} X {W2EBWidth}_{W2EBColour}_EB,{L2EBThickness} X {L2EBWidth}_{L2EBColour}_EB,{TopLaminate},{TopBarCode},{BottomLaminate},{BottomBarCode},{CutLength},{CutWidth},{CutThickness},{FinishedLength},{FinishedWidth},{FinishedThickness},{Quantity},{FinishedGrainDir},{TLGrainDir},{BLGrainDir}",
          FieldNames:
            "OrderNumber,OrderName,OrderDate,POSNo,Description,Panel barcode,ArticleName,FinalBoardOutput,Material,EdgeBottom W1,EdgeTop L1,EdgeRight W2,EdgeLeft L2,SurfaceTop,Top barcode,SurfaceBottom,Bottom barcode,CutLength,CutWidth,CutThickness,FinishedLength,FinishedWidth,FinishedThickness,Qty,GrainFlag,TL Grain direction,BL Grain direction",
        },
      ];
const readExcel=(file)=>{
    const promise=new Promise((resolve, reject)=>{
        const fileReader=new FileReader()
        fileReader.readAsArrayBuffer(file)
        fileReader.onload=(e)=>{
            const bufferArray=e.target.result; 
            const wb=XLSX.read(bufferArray, {type:"buffer"}) 
            const wsname=wb.SheetNames[0]; 
            const ws=wb.Sheets[wsname]
            const data=XLSX.utils.sheet_to_json(ws) 
            resolve(data)
        } 
        fileReader.onerror=(error)=>{
            reject(error)
        }
    }); 
    // console.log(setItems(d).map( (item) => item.key), "ccc");

    promise.then((c)=>{ 
        
        console.log(c)  
        setItems(c)
        console.log(setItems, "chetan")
        
        
    })
} 
const handleChange = (event) => {

    // debugger
    setFormat(event.target.value);  
    
    console.log("data",data);
    console.log("value",event.target.value)

     const reportData = data.filter((item) => item.SetName === event.target.value) //assuming event.traget.value would be either Report1,report2 or 3

    
     const fieldNamesArray= reportData[0].FieldNames.split(",") 

    //  console.log(items.map( (item) => item.key), "ccc")
    // debugger

    let finalvalues = [];

    // console.log("Gopi1",sheetData);
    console.log("Gopi2",fieldNamesArray);
    console.log("items",items)

    items.forEach((x) => {        
    //   debugger
      let finValue = {};

      fieldNamesArray.forEach(fields =>{
        finValue[fields] = x[fields]      
      });
    //   debugger
      console.log("finValue",finValue)
     
      finalvalues.push(finValue);
    });

    console.log("Gopi",finalvalues)       

  };   
  const convertExcelExport=(e)=>{
    if(excelData && e.item.id === 'excelexport'){
     (excelData).excelExport()
    }
  } 

   
  

  return (
    <div className='height-100 back' >     
        <input type="file" onChange={(e)=>{
            const file=e.target.files[0]
            readExcel(file)
        }} 
        />  
        <div className="d-flex flex-column dropdown-container">
        <FormControl>
          <Select
            disableUnderline={true}
            className="item-dropdown"
            MenuProps={{
              disableScrollLock: true,
              anchorOrigin: {
                vertical: "bottom",
                horizontal: "left",
              },
              getContentAnchorEl: null,
              placeholder: "Format",
            }}
            value={Format}
            // IconComponent={KeyboardArrowDownIcon}
            onChange={(e) => {
              handleChange(e);
            }}
          >
            {data.map((item) => (
              <MenuItem key={item} value={item.SetName}>
                {item.SetName}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>    


<div className='col mx-0 px-0 mr-2 back'> 


<GridComponent dataSource={items} ref={exe=>excelData=exe}
        allowRowDragAndDrop={true}
        allowExcelExport={true} 
        toolbar={['ExcelExport' ]} 
        toolbarClick={convertExcelExport()} />   

       <Inject services={[Toolbar, ExcelExport]} /> 
       </div>

        
        {/* </GridComponent> */}
          
    </div>
  )
}

export default Chetan