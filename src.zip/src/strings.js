const strings = {
    text_zip_file:"Drag & drop a file",

};