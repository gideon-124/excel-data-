import "./App.css";
import Chetan from "./Components/Chetan";
import Grid from "./Components/Grid";
import ParseExcelData from "./Components/ParseExcelData";
import ReadExcel from "./Components/ReadExcel";

function App() {
  return (
    <div>
      {/* <ReadExcel /> */}
      {/* <ParseExcelData /> */} 
      {/* <Grid/>  */}
      <Chetan/>
    </div>
  );
}
export default App;
